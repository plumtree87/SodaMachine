# This is a sample Python script.
from simulation import Simulation


simulation = Simulation()
simulation.run_simulation()
