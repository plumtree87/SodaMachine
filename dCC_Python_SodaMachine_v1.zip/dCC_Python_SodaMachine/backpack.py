

class Backpack:
    def __init__(self):
        self.purchased_cans = []
